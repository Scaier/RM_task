#include <iostream>
#include <math.h>
#include <opencv2/core.hpp>
#include <opencv2/core/matx.hpp>
#include <opencv2/highgui.hpp>
#include <ostream>

int main(int argc, const char *argv[])
{
    cv::Mat img = cv::imread("../picture_1.jpg", cv::IMREAD_COLOR);

    int width = img.rows;
    int height = img.cols;

    double _max, _min;
    double r, g, b;
    double h, s, v;
    double c, _h, x;
    double _r, _g, _b;
    double standard1, standard2, standard3;
    double max = 10, min = 0.7;

    cv::Mat hsv = cv::Mat::zeros(width, height, CV_32FC3);
    cv::Mat out = cv::Mat::zeros(width, height, CV_8UC3);

    for (int j = 0; j < width; j++)
    {
        for (int i = 0; i < height; i++)
        {
            // HSV
            r = (float)img.at<cv::Vec3b>(j, i)[2] / 255.0;
            g = (float)img.at<cv::Vec3b>(j, i)[1] / 255.0;
            b = (float)img.at<cv::Vec3b>(j, i)[0] / 255.0;

            _max = fmax(r, fmax(g, b));
            _min = fmin(r, fmin(g, b));

            v = _max;
            if (v > 0)
            {
                s = (_max - _min) / _max;
            }
            else
            {
                s = 0;
            }

            if (_max == r)
            {
                h = 60.0 * (g - b) / (_max - _min);
            }
            else if (_max == g)
            {
                h = 120.0 + 60 * (b - r) / (_max - _min);
            }
            else if (_max == b)
            {
                h = 240.0 + 60 * (r - g) / (_max - _min);
            }
            if (h < 0)
            {
                h = h + 360.0;
            }

            hsv.at<cv::Vec3f>(j, i)[0] = h;
            hsv.at<cv::Vec3f>(j, i)[1] = s;
            hsv.at<cv::Vec3f>(j, i)[2] = v;

            standard1 = hsv.at<cv::Vec3f>(0, 0)[0];
            standard2 = hsv.at<cv::Vec3f>(0, 0)[1];
            standard3 = hsv.at<cv::Vec3f>(0, 0)[2];

            if (h >= min * standard1 && h < max *standard1 && s >= min * standard2 && s <= max * standard2 && v >= min * standard3 && v <= max * standard3)
            {                                                       // Red color detection
                out.at<cv::Vec3b>(j, i) = cv::Vec3b(255, 255, 255); // White background
            }
            else
            {
                out.at<cv::Vec3b>(j, i) = img.at<cv::Vec3b>(j, i); // Black background
            }
        }
    }

    cv::imshow("img", img);
    cv::imshow("HSV", hsv);
    cv::imshow("answer", out);
    cv::waitKey(0);
    cv::destroyAllWindows();
}
