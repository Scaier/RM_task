#include <opencv2/opencv.hpp>

using namespace cv;
using namespace std;

int GaussianBlur(){
    cv::Mat src, dst;
    const char* filename = "../picture.jpg";

    cv::imread(filename).copyTo(src);
    if (src.empty()) {
        throw("Faild open file.");
    }

    int ksize1 = 11;
    int ksize2 = 11;
    double sigma1 = 10.0;
    double sigma2 = 20.0;
    cv::GaussianBlur(src, dst,cv::Size(ksize1,ksize2), sigma1, sigma2);
    //高斯模糊的函数
    //第三，第四，第五参数为高斯模糊的度数

    cv::imshow("src", src);
    cv::imshow("dst", dst);
    cv::imwrite("C:\\Code\\FirstOpenCVProgramming\\GaussianBlur.jpg", dst);

    cv::waitKey();

    return 0;
}

int main()
{
    GaussianBlur(); //图像高斯模糊化处理
    return 0;
}

