#include <iostream>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc/imgproc_c.h> 

using namespace std;
using namespace cv;

int main(int argc, const char* argv[]){

  cv::Mat img = imread("../furina.jpeg", IMREAD_COLOR);
  int width = img.rows;
  int height = img.cols;

  // RGB模块
  std::vector<cv::Mat> channels;
  cv::Mat imageBlueChannels;
  cv::Mat imageGreenChannels;
  cv::Mat imageRedChannels;
  // cv::Mat img = cv::imread("../furina.jpeg", cv::IMREAD_COLOR);
  cv::split(img, channels);
  imageBlueChannels = channels.at(0);
  imageGreenChannels = channels.at(1);
  imageRedChannels = channels.at(2);

  cv::imshow("imageBlueChannels", imageBlueChannels);
  cv::imshow("imageGreenChannels", imageGreenChannels);
  cv::imshow("imageRedChannels", imageRedChannels);
  // cv::waitKey(0);
  
  // Mat img = imread("../furina.jpeg", IMREAD_COLOR);
  // Mat img_1 = cv::imread("../furina.jpeg", 0);
  // imshow("ordinary", img);
  // imshow("img_1", img_1);
  // waitKey(0);

  // 灰度图模块

  // cv::Mat grey_image = cv::Mat::zeros(width, height, CV_8UC1);

  // for (int j=0; j<width; j++){
  //   for (int i=0; i<height; i++){
  //     grey_image.at<uchar>(j, i) = (int)((float)img.at<cv::Vec3b>(j,i)[0] * 0.0722 + \
  //                 (float)img.at<cv::Vec3b>(j,i)[1] * 0.7152 + \
  //                 (float)img.at<cv::Vec3b>(j,i)[2] * 0.2126);
  //   }
  // }

  // // HSV图模块
  // // 图像读取模块

  // double _max, _min;
  // double r, g ,b;
  // double h, s, v;
  // double c, _h, x;
  // double _r, _g, _b;

  // // 建立一个三通道空图
  // cv::Mat hsv_image = cv::Mat::zeros(width, height, CV_8UC3);

  // for (int j=0; j<width; j++){
  //   for (int i=0; i<height; i++){
  //     // HSV
  //     // 提取每个点的RGB数值
  //     r = (float)img.at<cv::Vec3b>(j,i)[2] / 255;
  //     g = (float)img.at<cv::Vec3b>(j,i)[1] / 255;
  //     b = (float)img.at<cv::Vec3b>(j,i)[0] / 255;

  //     // 提取最大和最小
  //     _max = fmax(r, fmax(g, b));
  //     _min = fmin(r, fmin(g, b));

  //     // 计算h
  //     if(_max == _min){
  //         h = 0;
  //     } else if (_min == b) {
  //         h = 60 * (g - r) / (_max - _min) + 60;
  //     } else if (_min == r) {
  //         h = 60 * (b - g) / (_max - _min) + 180;
  //     } else if (_min == g) {
  //         h = 60 * (r - b) / (_max - _min) + 300;
  //     }
  //     v = _max;
  //     s = _max - _min;

  //     // inverse hue
  //     h = fmod((h + 180), 360);

  //     // inverse HSV
  //     c = s;
  //     _h = h / 60;
  //     x = c * (1 - abs(fmod(_h, 2) - 1));

  //     _r = _g = _b = v - c;

  //     if (_h < 1) {
  //   _r += c;
  //   _g += x;
  //     } else if (_h < 2) {
  //   _r += x;
  //   _g += c;
  //     } else if (_h < 3) {
  //   _g += c;
  //   _b += x;
  //     } else if (_h < 4) {
  //   _g += x;
  //   _b += c;
  //     } else if (_h < 5) {
  //   _r += x;
  //   _b += c;
  //     } else if (_h < 6) {
  //   _r += c;
  //   _b += x;
  //     }

  //     hsv_image.at<cv::Vec3b>(j,i)[0] = (uchar)(_b * 255);
  //     hsv_image.at<cv::Vec3b>(j,i)[1] = (uchar)(_g * 255);
  //     hsv_image.at<cv::Vec3b>(j,i)[2] = (uchar)(_r * 255);
  //   }
  // }  

  // cv::imshow("picture!", img);
  // cv::imshow("grey_picture!", grey_image);
  // cv::imshow("hsv_picture!", hsv_image);
  cv::waitKey(0);
  cv::destroyAllWindows();

  return 0;

}
